import UIKit
import CoreData

class LoginViewController: UIViewController {
    
    
    @IBOutlet weak var UserName: UITextField!
    @IBOutlet weak var Password: UITextField!
    
    
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
     var userA : UserData?
     var userP : UserData?
    @IBAction func login(_ sender: Any)
    {
        
        let Uname = UserName.text!
        let Upass = Password.text!
        UserName.text = ""
        Password.text = ""
        let request : NSFetchRequest<UserData> = UserData.fetchRequest()
        let query = NSPredicate(format: "name == %@", "Uname")
        request.predicate = query
        request.fetchLimit = 1;      // command to tell the db to return 1 user
        
        do {
            let UserResults = try myContext.fetch(request)
            if UserResults.count == 0
            {
                
            }
            else
            {
                userP = UserResults[0]
            }
         
        }
        catch {
            print("Error while saving users")
        }
        
        
        let prequest : NSFetchRequest<UserData> = UserData.fetchRequest()
        
        let pquery = NSPredicate(format: "password == %@", "Upass")
        
        prequest.predicate = pquery
        prequest.fetchLimit = 1;      // command to tell the db to return 1 user
        
        do {
            let results = try myContext.fetch(prequest)
            if results.count == 0
            {
            
            }
            else
            {
                userA = results[0]
            }
            
        }
        catch {
            print("Error while saving users")
        }
        
        
        
        
        
        
        //check if fields are empty
        if(Uname.isEmpty || Upass.isEmpty)
        {
            displayMyAlertMessage(userMessage: "all fields must be filled");
            return;
        }
        
        //check if username and password are correct
        if(Uname == userA || Upass == userP)
        {
            
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
// Do any additional setup after loading the view.
             }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func displayMyAlertMessage(userMessage:String)
    {
        var myAlert = UIAlertController(title:"Alert", message:userMessage, preferredStyle:UIAlertControllerStyle.alert);
        let okAction = UIAlertAction(title:"ok", style:UIAlertActionStyle.default, handler:nil);
        myAlert.addAction(okAction);
        self.present(myAlert, animated:true, completion:nil);
    }
}

