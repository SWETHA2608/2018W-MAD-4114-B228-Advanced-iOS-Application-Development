//
//  ViewController.swift
//  instagram
//
//  Created by MacStudent on 2018-03-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController {

    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var rePassword: UITextField!
    
    let myContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var user = [UserData]()
    var usersData : UserData?
    // actions
    @IBAction func signUp(_ sender: Any)
        
    {
        // get the username and password from the text boxes
        let name = username.text!
        let pass = password.text!
        let email_ = email.text!
        let rePassword_ = rePassword.text!
        
        
        // create a new user
        let user = UserData(context: self.myContext)
        user.username = name
        user.password = pass
        user.email = email_
        
        if(pass != rePassword_)
        {
            displayMyAlertMessage(userMessage: "password do not match");
            //display an alert message
            
            return;
        }
        //check if fields are empty
        if(name.isEmpty || pass.isEmpty || email_.isEmpty)
        {
            displayMyAlertMessage(userMessage: "all fields must be filled");
            return;
        }
    // save the user to the database
        saveData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        
        let path = FileManager.default.urls(for:.documentDirectory, in:.userDomainMask)
        print(path)
        
        if (usersData != nil) {
            loadData()
        }    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func displayMyAlertMessage(userMessage:String)
    {
        var myAlert = UIAlertController(title:"Alert", message:userMessage, preferredStyle:UIAlertControllerStyle.alert);
        let okAction = UIAlertAction(title:"ok", style:UIAlertActionStyle.default, handler:nil);
        myAlert.addAction(okAction);
        self.present(myAlert, animated:true, completion:nil);
    }

    func loadData() {
        
        // search the database for all movies that match the category name
        
        let request : NSFetchRequest<UserData> = UserData.fetchRequest()
        
        let predicate = NSPredicate(format: "user.name MATCHES %@", usersData!.username!)
        
        request.predicate = predicate
        
        do  {
            user = try myContext.fetch(request)
        }
        catch {
            print("error: \(error)")
        }
        print(user)
    }
    
    
    func saveData() {
        print("Saving data")
        do {
            // get context and try to save
            try myContext.save()
        }
        catch {
            print("error saving data: \(error)")
        }
        
        print("done saving data")
    }
    
}


